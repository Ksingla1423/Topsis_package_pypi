from .topsis_102203080 import topsis, validate_inputs
